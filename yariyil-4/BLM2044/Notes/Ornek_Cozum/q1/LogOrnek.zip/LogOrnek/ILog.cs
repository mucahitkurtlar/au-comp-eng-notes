namespace LogOrnek
{
    public interface ILog
    {
        void logmesaji();
    }
}